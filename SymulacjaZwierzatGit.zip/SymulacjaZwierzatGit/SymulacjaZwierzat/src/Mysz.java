
public class Mysz extends Zwierze {
	
	public Mysz() {
		super(10, "Mysz");
	}
	
}
